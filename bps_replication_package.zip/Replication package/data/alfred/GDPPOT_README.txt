Series ID: GDPPOT
Link: https://alfred.stlouisfed.org/series?seid=GDPPOT
Help: https://alfred.stlouisfed.org/help

ALFRED (ArchivaL Federal Reserve Economic Data)
Economic Research Division
Federal Reserve Bank of St. Louis

Output Format: Observations by Vintage Date, All Observations
File Created: 2023-05-15 1:24 PM CDT

                                                                             Real-Time Period     
Title                                                                       Start         End     
--------------------------------------------------------------------------------------------------
Real Potential Gross Domestic Product                                     1991-01-30    Current   

Source
--------------------------------------------------------------------------------------------------
U.S. Congressional Budget Office                                          1991-01-30    Current   

Release
--------------------------------------------------------------------------------------------------
Economic and Budget Outlook                                               1991-01-30   1999-07-28 
Budget and Economic Outlook                                               1999-07-29    Current   

Units
--------------------------------------------------------------------------------------------------
Billions of 1982 Dollars                                                  1991-01-30   1992-01-21 
Billions of 1987 Dollars                                                  1992-01-22   1996-04-16 
Billions of Chained 1992 Dollars                                          1996-04-17   2000-01-26 
Billions of Chained 1996 Dollars                                          2000-01-27   2004-09-12 
Billions of Chained 2000 Dollars                                          2004-09-13   2010-01-25 
Billions of Chained 2005 Dollars                                          2010-01-26   2014-02-03 
Billions of Chained 2009 Dollars                                          2014-02-04   2019-01-27 
Billions of Chained 2012 Dollars                                          2019-01-28    Current   

Frequency
--------------------------------------------------------------------------------------------------
Quarterly                                                                 1991-01-30    Current   

Seasonal Adjustment
--------------------------------------------------------------------------------------------------
Not Seasonally Adjusted                                                   1991-01-30    Current   

Notes
--------------------------------------------------------------------------------------------------
Note: For the years 1991 through 1998, only the data that were current    1991-01-30   2004-09-12 
as of the CBO director's testimony before the Congressional Budget    
Committees is recorded. Starting with 1999, both the testimony data as
well as an update (usually during the late summer) are recorded.      

Note: For the years 1991 through 1998, only the data that were current    2004-09-13   2010-01-25 
as of the CBO director's testimony before the Congressional Budget    
Committees is recorded. Starting with 1999, both the testimony data as
well as an update (usually during the late summer) are recorded.      
                                                                      
Potential Real GDP is estimated by the Congressional Budget Office    
(CBO). Since the July 2009 NIPA revision, there is a discrepancy      
between real GDP (in billions of chained 2005 dollars) and CBO real   
potential GDP (in billions of Chained 2000 dollars). To convert the   
data to 2005 Dollars multiply each quarterly observation of CBO real  
potential GDP by a factor of 1.14. This scaling factor is the average 
of the ratio of real GDP in billions of chained 2005 dollars to real  
GDP in billions of chained 2000 dollars for the four quarters of 2005.
The CBO will be adjusting potential GDP sometime in 2010 to chained   
2005 dollars.                                                         

Real potential GDP is the CBO’s estimate of the output the economy      2010-01-26    Current   
would produce with a high rate of use of its capital and labor        
resources. The data is adjusted to remove the effects of inflation.   


Vintage Dates Specified:

1991-01-30
1992-01-22
1993-01-26
1994-01-27
1995-02-01
1996-04-17
1997-01-28
1998-01-28
1999-01-29
1999-07-29
2000-01-27
2000-07-19
2001-02-01
2001-09-04
2002-02-01
2002-08-29
2003-03-04
2003-09-02
2004-01-27
2004-09-13
2005-01-25
2005-08-31
2006-01-26
2006-08-17
2007-01-24
2007-08-23
2008-01-23
2008-09-09
2009-01-08
2009-08-27
2010-01-26
2010-08-23
2011-02-02
2011-08-24
2012-01-31
2012-08-22
2013-02-05
2014-02-04
2014-08-27
2015-01-26
2015-08-25
2016-01-25
2016-08-24
2017-01-24
2017-06-29
2018-04-09
2018-08-13
2019-01-28
2019-08-21
2020-01-28
2020-08-03
2021-02-01
2021-07-01
2022-05-26
2023-02-15
