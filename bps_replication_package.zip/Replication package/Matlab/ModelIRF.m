%Simulate a two-state Markov Chain for gamma, and solve for rational
%maximum likelihood inference

%Assumed MP coefficient follows random walk: gamma_t=gamma_{t-1}+xi_t
%Assumed output gap process: x_t=rho x_{t-1}+epsilon_t
%Interest rate process: i_t=gamma_t x_t+u_t

model2.sigma_epsilon=1.2;
model2.sigma_u=0.05;
model2.sigma_xi=0.1;
model2.rho=0.95;
model2.kappa=1;
model2.rho_gamma=1;

%initialize simulation
model2.T=3000;

%window for rolling regressions
model2.Tr=20;

%number of simulations
model2.Nsim=2000;

% different versions of rationality
model2_rational=model2;
model2_kappa=model2;
model2_kappa.kappa=0.1;
model2_rho_gamma=model2;
model2_rho_gamma.rho_gamma=0.97;
model2_all=model2;
model2_all.kappa=model2_kappa.kappa;
model2_all.rho_gamma=model2_rho_gamma.rho_gamma;

%% Simulate model
model2_rational=Simulate2(model2_rational);
model2_kappa=Simulate2(model2_kappa);
model2_rho_gamma=Simulate2(model2_rho_gamma);
model2_all=Simulate2(model2_all);
%% plot impulse responses with confidence intervals
horizon=(0:100);

h=figure;
subplot(2,1,1)
plot(horizon, mean(model2_rational.b1_mean)*ones(101,1),'k','LineWidth',2)
hold on 
plot(horizon, model2_kappa.b1_mean,'--','Color',[0.8500 0.3250 0.0980],'LineWidth',2)
plot(horizon, zeros(101,1),'k')
xlim([0,12])
ylim([-0.03,0.4])
%yticks([0,0.2,0.4,0.6,0.8,1])
hold off
legend('Rational','Overconfidence','Location','NorthWest')
xlabel('Horizon h')
ylabel('Perceived \gamma')
title('Conditional on strong economy')


subplot(2,1,2)
plot(horizon, mean(model2_rational.b2_mean)*ones(101,1),'k','LineWidth',2)
hold on 
plot(horizon, model2_kappa.b2_mean,'--','Color',[0.8500 0.3250 0.0980],'LineWidth',2)
plot(horizon, zeros(101,1),'k')
xlim([0,12])
ylim([-0.4,0.03])
hold off

xlabel('Horizon h')
ylabel('Perceived \gamma')
title('Conditional on weak economy')

saveas(h, './figures/gamma_IRF_rationality.png','png'); 


