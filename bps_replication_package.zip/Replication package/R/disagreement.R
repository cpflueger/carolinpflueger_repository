## calculate term structure of disagreement

library(dplyr)

load("data/bc_May23.RData")

## disagreement
da <- bc %>%
    group_by(date, h) %>%
    summarise(d_g = sd(rgdp, na.rm=TRUE),
              d_gap = sd(gap, na.rm=TRUE),
              d_ff = sd(ff, na.rm=TRUE),
              d_pi = sd(cpi, na.rm=TRUE), .groups="drop")

## da %>% summarise(across(everything(), ~sum(is.na(.x))))

## term structure of disagreement
tsda <- da %>%
    group_by(h) %>%
    summarise(across(c(d_g, d_gap, d_ff, d_pi), \(x) mean(x, na.rm=TRUE)))

pdf("figures/disagreement.pdf", width=5, height=3, pointsize=11)
## dev.new()
par(mar=c(4,4,.5,.5), mgp=c(2,.6,0))
plot(0:5, tsda$d_g, ylim=c(0,max(tsda[,-1])), type="l", main="", xlab="Horizon (quarters)", ylab="Standard deviation", lwd=2)
lines(0:5, tsda$d_gap, col="blue", lwd=2)
lines(0:5, tsda$d_pi, col="red", lwd=2)
lines(0:5, tsda$d_ff, col="darkgreen", lwd=2)
legend("bottomright", c("Output growth", "Output gap", "CPI inflation", "Federal funds rate"), lty=1, col=c("black", "blue", "red", "darkgreen"), lwd=2, cex=0.8)
dev.off()
